﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace Online_Gym_Management
{
    public partial class AdminUserLog : System.Web.UI.Page
    {
        string Connection = ConfigurationManager.ConnectionStrings["dbconnection"].ConnectionString;
        String Key,comment, id;
        protected void Page_Load(object sender, EventArgs e)
        {
            Button2.Enabled = false;
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            SqlConnection con=new SqlConnection(Connection);
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT [id],[productid],[productname],[review],[star] ,[username] FROM [Fakeptoductreviewsystemwallet].[dbo].[review]",con);
            SqlDataAdapter adpt = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            adpt.Fill(dt);
            GridView1.DataSource = dt;
            GridView1.DataBind();
            con.Close();
            Button2.Enabled = true;


        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            GetKeywords();
            Button2.Enabled = true;
        }

        private void GetKeywords()
        {
            using (SqlConnection con = new SqlConnection(Connection))
            {
                con.Open();
                using (SqlCommand cmd = new SqlCommand("SELECT * FROM Keyword", con))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        for (int i = 0; i < dt.Rows.Count; i++)
                        {
                            Key = dt.Rows[i][0].ToString().ToLower().Trim();
                            CheckKeywordsInReviews();
                        }
                    }
                }
            }
        }

        private void CheckKeywordsInReviews()
        {
            using (SqlConnection con = new SqlConnection(Connection))
            {
                con.Open();
                using (SqlCommand cmd = new SqlCommand("SELECT * FROM review", con))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        da.Fill(dt);

                        for (int i = 0; i < dt.Rows.Count; i++)
                        {
                            comment = dt.Rows[i][3].ToString().ToLower().Trim();
                            id = dt.Rows[i][0].ToString();
                            if (comment.Contains(Key))
                            {
                                updatereview();
                                // If any keyword is found, you might want to take appropriate action.
                                // For example, you can display a message or store the information in a list.
                                Label1.Text = "Check Completed";
                                //return; // Exit the loop if a match is found for the current review.
                            }
                            else 
                            {
                                Label1.Text = "Check Completed";
                            }
                        }
                    }
                }
            }
        }

        private void updatereview()
        {
            SqlConnection con = new SqlConnection(Connection);
            con.Open();
            SqlCommand com = new SqlCommand("Update review set Category='fake' where id='"+id+"' ",con);
            com.ExecuteNonQuery();
            con.Close();
        }

    }
}