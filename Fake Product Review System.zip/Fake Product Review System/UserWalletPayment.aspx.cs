﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace Fake_Product_Review_System
{
    public partial class UserWalletPayment : System.Web.UI.Page
    {
        string Connection = ConfigurationManager.ConnectionStrings["dbconnection"].ConnectionString;
        String Balance,BillType;
        protected void Page_Load(object sender, EventArgs e)
        {
           Label2.Text= Session["UserName"].ToString();
           TextBox5.Text = DateTime.Now.ToString();
           getWalletBalance();
        }

        private void getWalletBalance()
        {
            SqlConnection con = new SqlConnection(Connection);
            SqlCommand cmd = new SqlCommand("select Balance from WalletBalance where EmailId='"+Label2.Text+"'", con);
            con.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.Read()) // If data is found
            {
                Balance = reader["Balance"].ToString(); // Assign the value to the TextBox
                Label1.Text = Balance;

            }
            con.Close();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            int bal = Convert.ToInt32(Balance);
            int amt = Convert.ToInt32(TextBox4.Text);
            if (bal >= amt)
            {
                SqlConnection con = new SqlConnection(Connection);
                SqlCommand cmd = new SqlCommand("UPDATE WalletPayment SET [PaymentDate] = '" + TextBox5.Text + "',[PaymentStatus] = 'Paid' where Email='" + Label2.Text + "' and OrderId='" + TextBox1.Text + "'", con);
                con.Open();
                cmd.ExecuteNonQuery();
                detuctBalance();
                con.Close();
               
                Label3.Text = "Payment Successfull";
                
            }
            else
            {
                Label3.Text = "Insufficent Balance"; 
            }
            getWalletBalance();

            TextBox1.Text = "";
            TextBox2.Text = "";
            TextBox3.Text = "";
            TextBox4.Text = "";
            TextBox5.Text = "";

        }

        private void detuctBalance()
        {
            int bal = Convert.ToInt32(Balance);
            int amt = Convert.ToInt32(TextBox4.Text);
            int total=bal-amt;

            SqlConnection con = new SqlConnection(Connection);
            SqlCommand cmd = new SqlCommand("UPDATE WalletBalance SET Balance='" + total + "' where EmailId='" + Label2.Text + "'", con);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridViewRow row = GridView1.SelectedRow;
            TextBox1.Text = row.Cells[1].Text;
            TextBox2.Text = row.Cells[2].Text;
            TextBox3.Text = row.Cells[3].Text;
            TextBox4.Text = row.Cells[4].Text;
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            if (DropDownList1.Text == "Paid") { BillType = "Paid"; }
            if (DropDownList1.Text == "Un Paid") { BillType = "Null"; }
            SqlConnection Conn = new SqlConnection(Connection);
            SqlCommand Com = new SqlCommand("select * from WalletPayment where Email='"+Label2.Text+"' and PaymentStatus='" + BillType + "'", Conn);
            SqlDataAdapter sda = new SqlDataAdapter(Com);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }
    }
}