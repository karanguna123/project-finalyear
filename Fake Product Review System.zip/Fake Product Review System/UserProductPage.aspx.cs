﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace Online_Gym_Management
{
    public partial class UserProductPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["EMAIL"] == null)
            {
                
            }
            else
            {
                Label5.Text = Session["EMAIL"].ToString();
            }



            {
                DataTable dt = new DataTable();
                dt = (DataTable)Session["buyitems"];
                if (dt != null)
                {

                    Label6.Text = dt.Rows.Count.ToString();
                }
                else
                {
                    Label6.Text = "0";

                }

            }

        }

        protected void DataList1_ItemCommand(object source, DataListCommandEventArgs e)
        {
            if (e.CommandName == "addtocart")
            {
                DropDownList dlist = (DropDownList)(e.Item.FindControl("DropDownList1"));
                Response.Redirect("UserProductCart.aspx?id=" + e.CommandArgument.ToString() + "&quantity=" + dlist.SelectedItem.ToString());
            }
            if (e.CommandName == "viewdetails")
            {
                Response.Redirect("UserProductDetails.aspx?id=" + e.CommandArgument.ToString());
            }
        }

        
    }
}