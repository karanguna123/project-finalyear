﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace Fake_Product_Review_System
{
    public partial class AdminWallet : System.Web.UI.Page
    {
        string mycon = ConfigurationManager.ConnectionStrings["dbconnection"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {
            Panel1.Visible = false;
            Panel2.Visible = false;
            Panel3.Visible = false;
            Panel4.Visible = false;
            findorderid();
            TextBox5.Text=DateTime.Now.ToString();
        }

        protected void RadioButton1_CheckedChanged(object sender, EventArgs e)
        {
            Panel1.Visible = true;
            Panel2.Visible = false;
            Panel3.Visible = false;
            Panel4.Visible = false;
            RadioButton2.Checked = false;
            RadioButton3.Checked = false;
            RadioButton4.Checked = false;

        }

        protected void RadioButton2_CheckedChanged(object sender, EventArgs e)
        {
            Panel2.Visible = true;
            Panel1.Visible = false;
            Panel3.Visible = false;
            Panel4.Visible = false;
            RadioButton1.Checked = false;
        }

        protected void RadioButton3_CheckedChanged(object sender, EventArgs e)
        {
            Panel3.Visible = true;
            Panel1.Visible = false;
            Panel2.Visible = true;
            Panel4.Visible = false;
            RadioButton4.Checked = false;
        }

        protected void RadioButton4_CheckedChanged(object sender, EventArgs e)
        {
            Panel2.Visible = true;
            Panel4.Visible = true;
            Panel1.Visible = false;
            Panel3.Visible = false;
            RadioButton3.Checked = false;
        }
        public void findorderid()
        {
            String pass = "abcdefghijklmnopqrstuvwxyz123456789";
            Random r = new Random();
            char[] mypass = new char[5];
            for (int i = 0; i < 5; i++)
            {
                mypass[i] = pass[(int)(35 * r.NextDouble())];

            }
            String orderid;
            orderid = "" + DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString() + DateTime.Now.Day.ToString() + DateTime.Now.Month.ToString() + DateTime.Now.Year.ToString() + new string(mypass);
            TextBox1.Text = orderid;
        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(mycon);
            SqlCommand cmd = new SqlCommand("INSERT INTO WalletPayment values ('" + TextBox1.Text + "','" + TextBox2.Text + "','" + TextBox3.Text + "','" + TextBox4.Text + "','" + TextBox5.Text + "','Null','Null')", con);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            Label6.Text = "Bill Generated Successfully";
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(mycon);
            SqlCommand cmd = new SqlCommand("INSERT INTO WalletBalance values ('" + TextBox6.Text + "','" + TextBox7.Text + "','" + TextBox8.Text + "','" + TextBox9.Text + "','" + TextBox10.Text + "')", con);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            Label6.Text = "Wallet Created Successfully";
        }

        protected void Button5_Click(object sender, EventArgs e)
        {
            Panel2.Visible = true;
            Panel4.Visible = true;
            SqlConnection Conn = new SqlConnection(mycon);
            SqlCommand Com = new SqlCommand("select * from WalletBalance where EmailId='" + TextBox13.Text + "'", Conn);
            SqlDataAdapter sda = new SqlDataAdapter(Com);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            GridView2.DataSource = dt;
            GridView2.DataBind();
        }

        protected void GridView2_SelectedIndexChanged(object sender, EventArgs e)
        {
            Panel2.Visible = true;
            Panel4.Visible = true;
            GridViewRow row = GridView2.SelectedRow;
            Label7.Text = row.Cells[1].Text;
            Label8.Text = row.Cells[2].Text;
            Label9.Text = row.Cells[3].Text;
            Label10.Text = row.Cells[4].Text;
            Label11.Text = row.Cells[5].Text;
        }

        protected void Button6_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(mycon);
            SqlCommand cmd = new SqlCommand("update WalletBalance set Balance='"+TextBox14.Text+"'", con);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            Label6.Text = "Balance Updated Successfully";
        }
    }
}