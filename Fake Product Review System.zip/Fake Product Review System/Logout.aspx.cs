﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace Online_Gym_Management
{
    public partial class Logout : System.Web.UI.Page
    {   
        String Name;
        string Connection = ConfigurationManager.ConnectionStrings["dbconnection"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {
            Name=Session["UserName"].ToString();
           
            Session.Clear();
            Session.Abandon();
            Response.Redirect("Default.aspx");

        }
    }
}