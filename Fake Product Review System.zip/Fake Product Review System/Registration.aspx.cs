﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace Online_Gym_Management
{
    public partial class Registration : System.Web.UI.Page
    {
        string Connection = ConfigurationManager.ConnectionStrings["dbconnection"].ConnectionString;
        String mycon = ConfigurationManager.ConnectionStrings["dbconnection"].ConnectionString;
        String strname;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

       
        private Boolean checkemail()
        {
            Boolean emailavailable = false;
            String myquery = "Select * from Login where Username='" + TextBox6.Text + "'";
            SqlConnection con = new SqlConnection(mycon);
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = myquery;
            cmd.Connection = con;
            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = cmd;
            DataSet ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                emailavailable = true;

            }
            con.Close();

            return emailavailable;
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            

            if (FileUpload1.HasFile)
            {
                strname = FileUpload1.FileName.ToString();
                FileUpload1.PostedFile.SaveAs(Server.MapPath("~/Upload/") + strname);
                String path = "~/Upload/" + strname;
                if (checkemail() == true)
                {
                    Label1.Text = "Your Email Already Registered with Us";
                    TextBox3.BackColor = System.Drawing.Color.PaleGreen;


                }
                else
                {
                    String query = "insert into UserRegistration([FName],[LName],[Email],[Mobile],[Address],[Username],[Password],[Photo]) values('" + TextBox1.Text + "','" + TextBox2.Text + "','" + TextBox3.Text + "','" + TextBox4.Text + "','" + TextBox5.Text + "','" + TextBox6.Text + "','" + TextBox8.Text + "','" + path + "')";
                    SqlConnection con = new SqlConnection(mycon);
                    con.Open();
                    SqlCommand com=new SqlCommand("Insert into Login values('"+TextBox6.Text+"','"+TextBox8.Text+"','User')",con);
                    com.ExecuteNonQuery();
                    SqlCommand cmd = new SqlCommand();
                    cmd.CommandText = query;
                    cmd.Connection = con;
                    cmd.ExecuteNonQuery();
                    Label1.Text = "Registration Has Been Saved Successfully";
                    Clear();
                }
            }
            else
            {
                Label1.Visible = true;
                Label1.Text = "Plz upload the image!!!!";
            }  


           
        }

        private void Clear()
        {
            TextBox1.Text = "";
            TextBox2.Text = "";
            TextBox3.Text = "";
            TextBox4.Text = "";
            TextBox5.Text = "";
            TextBox6.Text = "";
            TextBox7.Text = "";
            TextBox8.Text = "";
        }

         
    }
}