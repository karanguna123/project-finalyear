﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Net.Mail;

namespace Fake_Product_Review_System
{
    public partial class AdminDispatchOrders : System.Web.UI.Page
    {
        string mycon = ConfigurationManager.ConnectionStrings["dbconnection"].ConnectionString;
        String updateStatus;        
        String Status;
        int otp;
        protected void Page_Load(object sender, EventArgs e)
        {
            TextBox2.Text = DateTime.Now.ToString();
        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            if (DropDownList1.Text == "Open") { Status = "Null"; }
            if (DropDownList1.Text == "Completed") { Status = "Completed"; }
            if (DropDownList1.Text == "On Delivery") { Status = "Enroute"; }
            SqlConnection Conn = new SqlConnection(mycon);
            SqlCommand Com = new SqlCommand("select * from OrderDispatch where DeliveryStatus='" + Status + "'", Conn);
            SqlDataAdapter sda = new SqlDataAdapter(Com);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridViewRow row = GridView1.SelectedRow;
            Label1.Text = row.Cells[1].Text;
            Label2.Text = row.Cells[7].Text;
            Label3.Text = row.Cells[3].Text;

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            if (DropDownList2.Text == "Open") { updateStatus = "Null"; }
            if (DropDownList2.Text == "Completed") { updateStatus = "Completed"; }
            if (DropDownList2.Text == "On Delivery") { updateStatus = "Enroute"; }
            GenerateOtp();
            SqlConnection Conn = new SqlConnection(mycon);
            SqlCommand Com = new SqlCommand("UPDATE OrderDispatch SET DispatchStatus = '" + TextBox1.Text + "',DispatchTime = '" + TextBox2.Text + "',DeliveryStatus = '" + updateStatus + "',Remarks = '" + TextBox4.Text + "' WHERE orderid='" + Label1.Text + "'", Conn);
            SqlCommand com1=new SqlCommand("insert into Otp values ('"+Label1.Text+"','"+Label2.Text+"','"+otp+"')",Conn);
            Conn.Open();
            Com.ExecuteNonQuery();
            com1.ExecuteNonQuery();
            Conn.Close();

            MailMessage msg = new MailMessage();
            msg.To.Add(Label2.Text);
            msg.From = new MailAddress("testertestertester1818@gmail.com");
            msg.Subject = "Otp for purchase";
            msg.Body = "Otp for purchase of '"+Label3.Text+"' is : " + otp + "";

            SmtpClient smtp = new SmtpClient();
            smtp.Host = "smtp.gmail.com";
            smtp.Port = 587;
            smtp.EnableSsl = true;
            smtp.UseDefaultCredentials = true;
            smtp.Credentials = new System.Net.NetworkCredential("testertestertester1818@gmail.com", "hngidkrapgrqybyt");
            smtp.Send(msg);

            Label1.Text = "";
            Label2.Text = "";
            Label3.Text = "";
            TextBox1.Text = "";
            TextBox2.Text = "";
            TextBox4.Text = "";
            Label4.Text = "Dispatched Successfullt";

        }

        private void GenerateOtp()
        {
            Random random = new Random();
            otp = random.Next(100000, 999999);
        }

        
    }
}