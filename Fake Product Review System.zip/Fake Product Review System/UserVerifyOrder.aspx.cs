﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace Fake_Product_Review_System
{
    public partial class UserVerifyOrder : System.Web.UI.Page
    {
        string Connection = ConfigurationManager.ConnectionStrings["dbconnection"].ConnectionString;
        String dbotp;
        protected void Page_Load(object sender, EventArgs e)
        {
            Label1.Text = Session["UserName"].ToString();
            Panel1.Visible = false;
            Panel2.Visible = false;

        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridViewRow row = GridView1.SelectedRow;
            Label2.Text = row.Cells[1].Text;
        }

        protected void RadioButton1_CheckedChanged(object sender, EventArgs e)
        {
            RadioButton2.Checked = false;
            Panel1.Visible = true;
            Panel2.Visible = false;            
        }

        protected void RadioButton2_CheckedChanged(object sender, EventArgs e)
        {
            RadioButton1.Checked = false;
            Panel1.Visible = false;
            Panel2.Visible = true;
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(Connection);
            SqlCommand cmd = new SqlCommand("insert into VerifiedOrder values ('" + Label2.Text + "','" + Label1.Text + "','Null','"+DropDownList1.Text+"','"+TextBox2.Text+"')", con);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            Label3.Text = "Request Raised";
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
           fetchOpt();
           if (dbotp == TextBox1.Text)
           {
               SqlConnection con = new SqlConnection(Connection);
               SqlCommand cmd = new SqlCommand("insert into VerifiedOrder values ('" + Label2.Text + "','" + Label1.Text + "','Verified','Null','Null')", con);
               SqlCommand com = new SqlCommand("DELETE FROM Otp WHERE Orderid='" + Label2.Text + "' and Email='" + Label1.Text + "'", con);
               con.Open();
               cmd.ExecuteNonQuery();
               com.ExecuteNonQuery();
               con.Close();
               Label3.Text = "order Verified";
           }
           else { Label3.Text = "otp Invalid"; }
        }

        private void fetchOpt()
        {
            SqlConnection con = new SqlConnection(Connection);
            SqlCommand cmd = new SqlCommand("select Otp from Otp where Orderid='"+Label2.Text+"' and Email='"+Label1.Text+"'", con);
            con.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.Read()) // If data is found
            {
                dbotp = reader["Otp"].ToString(); // Assign the value to the TextBox
            }
            con.Close();
        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            Panel2.Visible = true;
        }
    }
}