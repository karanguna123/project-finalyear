﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace Online_Gym_Management
{
    public partial class UserProductDetails : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["EMAIL"] == null)
            {
                Response.Redirect("loginpage.aspx");
            }
            else
            {
                Label16.Text = Session["EMAIL"].ToString();
            }
        }

        protected void DataList1_ItemCommand(object source, DataListCommandEventArgs e)
        {
            if (e.CommandName == "addtocart")
            {
                DropDownList dlist = (DropDownList)(e.Item.FindControl("DropDownList1"));
                Response.Redirect("UserProductCart.aspx?id=" + e.CommandArgument.ToString() + "&quantity=" + dlist.SelectedItem.ToString());
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Button BuyNowButton = (Button)sender;
            DataListItem item = (DataListItem)BuyNowButton.NamingContainer;
            Label NameLabel = (Label)item.FindControl("label10");
            Label14.Text = NameLabel.Text;
            Label NameLable1 = (Label)item.FindControl("label11");
            Label15.Text = NameLable1.Text;
            Bind_DataList();
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            SqlCommand comm = new SqlCommand();
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = "Data Source=.\\SQLEXPRESS;Initial Catalog=Fakeptoductreviewsystemwallet;Integrated Security=True";
            conn.Open();
            SqlCommand cmd = new SqlCommand("insert into review" + "(productid,productname,review,star,username)values(@productid,@productname,@review,@star,@username)", conn);
            cmd.Parameters.AddWithValue("@productid", Label14.Text);
            cmd.Parameters.AddWithValue("@productname", Label15.Text);
            cmd.Parameters.AddWithValue("@review", TextBox1.Text);
            cmd.Parameters.AddWithValue("@star", DropDownList2.Text);
            cmd.Parameters.AddWithValue("@username", Label16.Text);
            cmd.ExecuteNonQuery();
            Label9.Text = "Review Has Been Saved Successfully";
            TextBox1.Text = "";
            Bind_DataList();
        }

        private void Bind_DataList()
        {
            SqlCommand comm = new SqlCommand();
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = "Data Source=.\\SQLEXPRESS;Initial Catalog=Fakeptoductreviewsystemwallet;Integrated Security=True";
            if (conn.State == ConnectionState.Closed)
            {
                conn.Open();
            }

            SqlCommand cmd = new SqlCommand("select [id],[productid],[productname],[review],[star],[username] from review where productid='" + Label14.Text + "' and Category is null", conn);
            SqlDataAdapter adpData = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            adpData.Fill(dt);
            GridView1.DataSource = dt;
            GridView1.DataBind();
            conn.Close();
        }

    }
}