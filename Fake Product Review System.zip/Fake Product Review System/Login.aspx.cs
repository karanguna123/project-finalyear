﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace Online_Gym_Management
{
    public partial class Login : System.Web.UI.Page
    {
        string Connection = ConfigurationManager.ConnectionStrings["dbconnection"].ConnectionString;
        string str, UserName, Password;
        SqlCommand com = new SqlCommand();
        SqlDataAdapter sqlda;
        DataTable dt;
        int RowCount;
        protected void Page_Load(object sender, EventArgs e)
        {
            Label2.Text = DateTime.Now.ToString();
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("Registration.aspx");
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(Connection);
            con.Open();
            str = "Select * from [Login]";
            com = new SqlCommand(str);
            sqlda = new SqlDataAdapter(com.CommandText, con);
            dt = new DataTable();
            sqlda.Fill(dt);
            RowCount = dt.Rows.Count;

            


            for (int i = 0; i < RowCount; i++)
            {
                UserName = dt.Rows[i]["UserName"].ToString();
                Password = dt.Rows[i]["Password"].ToString();

            
                if (UserName == TextBox1.Text && Password == TextBox2.Text)
                {
                    Session["UserName"] = UserName;
                    if (dt.Rows[i]["Role"].ToString() == "User")
                    {
                        SqlCommand cmd = new SqlCommand("select Email from UserRegistration where Username='" + UserName + "'", con);
                        SqlDataAdapter sda = new SqlDataAdapter(cmd);
                        DataTable dt1 = new DataTable();
                        sda.Fill(dt1);
                        String Email = dt1.Rows[0]["Email"].ToString();
                        Session["EMAIL"] = Email;
                    //    savelogin();
                        Response.Redirect("UserDefault.aspx");
                    }
                    else if (dt.Rows[i]["Role"].ToString() == "Admin")
                    {
                        Response.Redirect("AdminDefault.aspx");
                    }

                }
                else
                {
                    Label1.Text = "Invalid User Name or Password! Please try again!";
                }
            }  
        }

        private void savelogin()
        {
            String Date=DateTime.Today.ToString();
            String Time= DateTime. Now. ToString("HH:mm");
            SqlConnection con = new SqlConnection(Connection);
            con.Open();


            SqlCommand cmd = new SqlCommand("Select * from UserLogs where UserName='" + UserName + "' and Date='"+Date+"'", con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt1 = new DataTable();
            sda.Fill(dt1);

            if (dt1.Rows.Count == 0)
            {
                SqlCommand com = new SqlCommand("Insert into UserLogs values ('" + UserName + "','" + Time + "','" + Date + "','LOGIN','NULL','NULL')", con);
                com.ExecuteNonQuery();
                con.Close();
            }
            else
            {
                String asd;
            }
               
                
            }
        }
    }